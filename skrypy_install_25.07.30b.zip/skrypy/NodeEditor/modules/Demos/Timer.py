class time_sleep():
    def __init__(self, duration_seconde=5):
        import time
        time.sleep(duration_seconde)
