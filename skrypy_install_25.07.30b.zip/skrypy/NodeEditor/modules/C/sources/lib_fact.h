#ifndef _LIB_FACT_H

	#define _LIB_FACT_H
	int fact(int n);

#endif
