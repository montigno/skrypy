class path_array_getElement():
    def __init__(self, array_path_in=[['path']], index_row=0, index_col=0):
        self.outPath = array_path_in[index_row][index_col]

    def outPath(self: 'path'):
        return self.outPath

###############################################################################
