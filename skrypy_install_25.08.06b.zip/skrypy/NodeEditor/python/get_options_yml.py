class get_options():
    def __init__(self, name_block, enters):
        pass
