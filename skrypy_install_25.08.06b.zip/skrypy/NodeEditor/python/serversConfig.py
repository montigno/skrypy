from Config import Config


class Servers_configuration():
    def __init__(self, parent=None):
        pass