import os


def cpu_count():
    cpu_cnt = os.cpu_count()
