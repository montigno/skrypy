class path_list_getElement():
    def __init__(self, list_path_in=['path'], index=0):
        self.outPath = list_path_in[index]

    def outPath(self: 'path'):
        return self.outPath
###############################################################################

