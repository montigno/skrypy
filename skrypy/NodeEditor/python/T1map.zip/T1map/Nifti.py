class nifti_save_file:
    def __init__(self, image=[[0.0]], nifti_path='path', **options):
        import nibabel as nib
        import numpy as np
        import os

        fn, extn = os.path.splitext(nifti_path)
        if 'out_type' in options.keys():
            extn = options['out_type']
        else:
            if extn not in ['.nii', '.gz']:
                extn = '.nii'
        self.fileSaved = '{}{}'.format(fn, '.nii')
        image = np.array(image, dtype=float)
        if 'header' in options.keys():
            hdr = options['header']
            if not hdr:
                hdr = np.eye(4)
                img = nib.Nifti1Image(image, hdr)
            else:
                img = nib.Nifti1Image(image, None, hdr)
        else:
            hdr = np.eye(4)
            img = nib.Nifti1Image(image, hdr)
        if 'print_header' in options.keys():
            print(hdr)
        nib.save(img, self.fileSaved)

    def pathFile(self: 'path'):
        return self.fileSaved
###############################################################################

class nifti_get_header():

    def __init__(self, nii_image='path'):
        import nibabel as nib
        img = nib.load(nii_image)
        self.hdr = img.header

    def nii_hdr(self: 'str'):
        return self.hdr

    def nii_hdr_dict(self: 'dict'):
        return dict(self.hdr)
###############################################################################

class nifti_open_file:
    def __init__(self, nifti_file='path'):
        import os.path
        import nibabel as nib
        import numpy as np
        self.dim = 0
        self.img = [[0.0]]
        if (os.path.splitext(nifti_file)[1] == '.nii') or \
           ('.nii.gz' in nifti_file):
            img = nib.load(nifti_file)
            # self.img = img.get_fdata()
            self.img = np.asarray(img.dataobj)
            self.dim = len(img.shape)
            self.pxd = img.header._structarr['pixdim']
        else:
            print('no Nifti file')

    def image(self: 'array_float'):
        return self.img

    def dim(self: 'int'):
        return self.dim

    def pixdim(self: 'list_float'):
        return self.pxd
###############################################################################

