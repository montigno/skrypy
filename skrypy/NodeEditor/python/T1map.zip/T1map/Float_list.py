class float_list_mean:

    def __init__(self, list_float_in=[0.0]):
        import numpy as np
        self.result = np.mean(list_float_in)

    def mean(self: 'float'):
        return self.result
###############################################################################

