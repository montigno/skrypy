class path_add_suffixprefix:
    def __init__(self,
                 path_in='path',
                 new_str='',
                 place="enumerate(('suffix','prefix'))"):
        import os
        dir = os.path.dirname(path_in)
        tmp = os.path.basename(path_in)
        name = ('.').join(tmp.split('.')[:-1])
        ext = tmp.split('.')[-1]
        if place == 'suffix':
            self.outPath = os.path.join(dir, name + new_str + '.'+ext)
        elif place == 'prefix':
            self.outPath = os.path.join(dir, new_str + name + '.'+ext)

    def newPath(self: 'path'):
        return self.outPath
###############################################################################

class path_change_extension:
    def __init__(self, path_in='path', new_extension='.txt'):
        import os
        pre, ext = os.path.splitext(path_in)
        self.outPath = os.path.join(pre + new_extension)

    def newPath(self: 'path'):
        return self.outPath
###############################################################################

class path_to_list_dyn():
    def __init__(self, path_in='path', **dynamicsInputs):
        self.outListPath = [path_in]
        for di in dynamicsInputs:
            self.outListPath.append(dynamicsInputs[di])

    def ListPath(self: 'list_path'):
        return self.outListPath
###############################################################################

