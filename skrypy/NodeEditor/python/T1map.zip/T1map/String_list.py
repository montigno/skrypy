class string_list_to_float_list():
    def __init__(self, listStr=['']):
        import numpy as np
        listStr = np.array(listStr)
        self.outlistfloat = list(listStr.astype(float))

    def outArrayFloat(self: 'list_float'):
        return self.outlistfloat
###############################################################################

