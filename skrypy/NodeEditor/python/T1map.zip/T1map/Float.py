class float_operations_dyn():
    def __init__(self, operation="enumerate(('add', 'sub', 'mul', 'div'))",
                 list_float_in=0.0, **dynamicsInputs):
        self.result = list_float_in
        if operation == 'add':
            for di, vi in dynamicsInputs.items():
                self.result = self.result + vi
        elif operation == 'sub':
            for di, vi in dynamicsInputs.items():
                self.result = self.result - vi
        elif operation == 'mul':
            for di, vi in dynamicsInputs.items():
                self.result = self.result * vi
        elif operation == 'div':
            for di, vi in dynamicsInputs.items():
                self.result = self.result / vi

    def out_result(self: 'float'):
        return self.result
###############################################################################

