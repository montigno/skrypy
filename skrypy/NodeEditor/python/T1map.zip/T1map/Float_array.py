class float_array_nlargest():
    """
    Check the n largest value in array input.

    Args:
        array_float_in: (array of float) array input
        n: (integer) number of desired largest values

    Returns:
        listMax: (list of float) list of n largest values of in_array

    Note:
        GUI: no
    """
    def __init__(self, array_float_in=[[0.0]], n=2):
        import numpy as np
        array_float_in = np.array(array_float_in)
        self.result_list = -np.sort(-array_float_in, axis=None)[0:n]

    def listMax(self: 'list_float'):
        return self.result_list.tolist()
###############################################################################

