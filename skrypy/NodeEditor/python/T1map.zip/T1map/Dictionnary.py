class dict_get_value_dyn():
    def __init__(self, input_dict={}, tag='', **dynamicsInputs):
        if tag in input_dict:
            self.outValue = input_dict[tag]
            for di, vi in dynamicsInputs.items():
                if vi in self.outValue:
                    self.outValue = self.outValue[vi]
                else:
                    self.outValue = None
                    break
        else:
            self.outValue = None

    def out_value(self: 'str'):
        return self.outValue

    def out_value_dict(self: 'dict'):
        if isinstance(self.outValue, dict):
            return dict(self.outValue)
        else:
            return {}
###############################################################################

