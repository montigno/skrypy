class string_array_getcolumn:
    def __init__(self, array_string_in=[['']], index_column=0):
        self.res = [row[index_column] for row in array_string_in]

    def out_column(self: 'list_str'):
        return self.res
###############################################################################

